<?php 




$servername = "localhost";
   $username = "raghu80504822"; 
    $password = "5EqjoMZIm2*b"; 
$dbname = "admin_onlinefees_all";
// create connection object


$con=mysqli_connect($servername,$username,$password,$dbname);



?>