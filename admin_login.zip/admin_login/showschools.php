<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common1.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: login.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to login.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 

?><!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>School List</title>
  
  
  <?php
  $x=$_SESSION['user'];
 
  ?>
      <link rel="stylesheet" href="css7/style.css">
</head>

<body>

  <div class="wrapper">
	<div class="container">
		<h1>Welcome</h1>
		
<?php 
include "config/config.php";
 $a=$_SESSION['user'];  
 $u=$a['username'];


  
 
$r=mysqli_query($con,"SELECT * FROM `schools` where `username`='$u'");

?>
<form>
<select onChange="window.open(this.options[this.selectedIndex].value,'_blank')" name="website">	
<option></option>

								  <?php 
								  
								 
								 while($row=mysqli_fetch_array($r))
									{
										?>
									<option value="<?php echo $row['schooldomain']; ?><?php echo'/testing.php?key='; echo $row['username']; ?>"  > <?php echo $row['schoolname']; ?></option>
									<?php 
									}
									?>
	  </select>
	</form>
	
	
	</div>
	
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
	
</div>
  <a href="logout.php">Logout</a>
      <script src='js7/jquery.min'></script>
      <script src='js7/jquery-ui.js'></script>
    
    
    
    <script  src="js7/index.js"></script>
    
    <!--<script type="text/javascript">
    window.onload = function(){
        location.href=document.getElementById("selectbox").value;
    }       
</script> -->
  
</body>

</html>
