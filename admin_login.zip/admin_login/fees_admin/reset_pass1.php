<?php
include "config/config.php";
//This code runs if the form has been submitted
if (!empty($_POST))
{

// check for valid email address
echo $email = $_POST['email'];

// checks if the username is in use
$check = mysqli_query($con,"SELECT email FROM users WHERE email = '$email'")or die(mysql_error());
echo "SELECT email FROM users WHERE email = '$email'";
$check2 = mysqli_num_rows($check);
echo $check2;
$error="hi";
//if the name exists it gives an error
if ($check2 == 0) {
echo "Email Is Not Valid";
$error = "not";
}


if ($error != "not") {
 
$p1=$_POST["password"];
$p2=$_POST["password1"];
 $flag=strcmp($p1,$p2);
if($flag == 0)
{

$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647)); 
$password = hash('sha256', $_POST['password'] . $salt); 
for($round = 0; $round < 65536; $round++) 
    { 
            $password = hash('sha256', $password . $salt); 
        }
         
$sql = mysqli_query($con,"UPDATE users SET `password`='$password',`salt`='$salt' WHERE email = '$email'")or die (mysql_error());

?>
<script>
alert("password is restored");
document.location="reset_pass.php";
</script>
<?php
}
?>
<script>
alert("password is incorrect");
document.location="reset_pass.php";
</script>
<?php
}
}

?>
