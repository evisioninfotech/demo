
<html >
<head>
<title>Assignment form</title>
</head>

<frameset rows="100,*" frameborder="no" border="0" framespacing="0">
  <frame src="h.php" name="topFrame" scrolling="No" noresize="noresize" id="topFrame" title="topFrame" target="mainFrame" />
  <frame src="UntitledFrame-1" name="mainFrame" id="mainFrame" title="mainFrame" />
</frameset>
<noframes><body>
</body>
</noframes></html>
