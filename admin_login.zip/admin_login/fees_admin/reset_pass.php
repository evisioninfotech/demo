

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
	font-weight: bold;
}
-->
</style>
</head>

<body>

<form action="reset_pass1.php" method="post">
  <p align="center" class="style1">Password Reset </p>
  <p align="center">E-Mail id:
    <input type="text" name="email" value="" />
    <br />
    <br />
    <br />
Password:
<input type="password" name="password" value="" />
  <br />
  <br />
  <br />
Reenter :
<input type="password" name="password1" value="" />
  </p>
  <p align="center">
    
    <input type="submit" name="submit" value="submit" />
    </p>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>