<?php
include "config/config.php";

$delete=$_GET["key"];


mysqli_query($con,"DELETE FROM `users` WHERE `users`.`username` = '$delete' ");
mysqli_query($con,"DELETE FROM `schools` WHERE `schools`.`username` = '$delete' ");

?>
<script>
alert("Data Is deleted");
	document.location="memberlist.php";

	</script>

