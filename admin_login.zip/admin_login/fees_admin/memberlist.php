<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common1.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 

     
    // Everything below this point in the file is secured by the login system 
     
    // We can retrieve a list of members from the database using a SELECT query. 
    // In this case we do not have a WHERE clause because we want to select all 
    // of the rows from the database table. 
    $query = " 
        SELECT 
            id, 
            username, 
            email,
			mobile 
        FROM users 
    "; 
     
    try 
    { 
        // These two statements run the query against your database table. 
        $stmt = $db->prepare($query); 
        $stmt->execute(); 
    } 
    catch(PDOException $ex) 
    { 
        // Note: On a production website, you should not output $ex->getMessage(). 
        // It may provide an attacker with helpful information about your code.  
        die("Failed to run query: " . $ex->getMessage()); 
    } 
         
    // Finally, we can retrieve all of the found rows into an array using fetchAll 
    $rows = $stmt->fetchAll(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap - Data Table</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css_sort/vendor/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="css_sort/vendor/font-awesome.min.css" type="text/css" rel="stylesheet">
    <link href="css_sort/css.css" rel='stylesheet' type='text/css'>
    <link href="css_sort/jquery.bdt.css" type="text/css" rel="stylesheet">
    <link href="css_sort/style.css" type="text/css" rel="stylesheet">
</head>
<body>
<h1 align="center">Memberlist</h1> 
   
   <div class="container">
    <div class="row">
            <div class="box clearfix">
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">
            <table class="table table-hover" id="bootstrap-table">
                <thead>

    <tr> 
        <th>Username</th>
		<th>ID</th> 
        <th>E-Mail Address</th> 
		<th>Mobile</th> 
		<th>Delete</th> 
    </tr>
	</thead>
        <tbody> 
    <?php foreach($rows as $row): ?> 
        <tr> 
            <td><?php echo htmlentities($row['username'], ENT_QUOTES, 'UTF-8'); ?></td> 
			            <td height="45"><?php echo $row['id']; ?></td> <!-- htmlentities is not needed here because $row['id'] is always an integer -->
            <td><?php echo htmlentities($row['email'], ENT_QUOTES, 'UTF-8'); ?></td> 
			<td><div align="center"><?php echo htmlentities($row['mobile'], ENT_QUOTES, 'UTF-8'); ?></div>		    </td> 
			<td><div align="center"><a href="delete.php?key=<?php echo htmlentities($row['username'], ENT_QUOTES, 'UTF-8'); ?>">DELETE</a></div></td> 
        </tr> 
    <?php endforeach; ?> 
	</tbody>
	
   
</table> </div></div></div>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("bootstrap-table");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
<script src="js_sort/jquery-2.1.1.min.js" type="text/javascript"></script>
<script src="js_sort/vendor/bootstrap.min.js" type="text/javascript"></script>
<script src="js_sort/vendor/jquery.sortelements.js" type="text/javascript"></script>
<script src="js_sort/jquery.bdt.min.js" type="text/javascript"></script>
<script>
    $(document).ready( function () {
        $('#bootstrap-table').bdt({
            showSearchForm: 0,
            showEntriesPerPageField: 0
        });
    });
</script>
</body>
</html>