<html>
<head>
<title>Hacked By Parker'z Gans</title>
<link rel="shortcut icon" type="image/x-icon" href="C"/>
<link rel="mask-icon" type="" href="https://i.ibb.co/MpdhKZM/IMG-20190920-WA0232.jpg" color="#111"/>
<meta charset="UTF-8">
<meta name="theme-color" content="black">
<meta content="./SAG1RI-SEC | 22XploiterCrew" name="description">
<meta content="./SAG1RI-SEC | 22XploiterCrew" name="keywords">
<meta content="./SAG1RI-SEC | 22XploiterCrew" name="Abstract">
<meta name="title" content="">
<meta name="keywords" content="./SAG1RI-SEC | 22XploiterCrew">
<meta name="googlebot" content="index,follow">
<meta name="robots" content="all">
<meta name="robots schedule" content="auto">
<meta name="distribution" content="global">
<meta name="theme-color" content="black">
<meta name="description" content="./SAG1RI-SEC | 22XploiterCrew">
<link href="https://fonts.googleapis.com/css?family=Iceland" rel="stylesheet" type="text/css">
<script type="text/javascript">
<!--
var message="22XploiterCrew";
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("alert(message);return false")
// --> 
</script>
<!-- Styles -->
<style>
            html, body {
                background-color: #000
               ;
                height: 100vh;
                margin: 0;
            }
            .full-height {
                height: 100vh;
            }
            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }
            .position-ref {
                position: relative;
            }
            .content {
                text-align: center;
            }
            .title {
                font-size: 36px;
                padding: 20px;
            }
</style>
</head>
<body align="center" oncontextmenu="return false">
<script type="text/javascript">
</script>
<div class="flex-center position-ref full-height">
	<div class="content">
		<div class="text">
			<center><img src="https://i.ibb.co/MpdhKZM/IMG-20190920-WA0232.jpg" width='600' height='600' align='center'>
			<code>
			<br>
			<font size="6"><font color="white" font="" face="Iceland">[ Hacked By Parker'z Gans - ./SAG1RI-SEC ]<font size="4"><font color="grey"><br>
			<br>
			<b></b></font><b>
			<font color="red">Official Member:<br> <font color="white">TumanGanz - root@Qwerty - NoT_R05 - ./Mr_Chaos - Mr.Riy <br>
			LucyDR334Ms - ./R4ND5 - ./B17CH - ./Ava_AzhariKun -./Mr.Google
			<br>
			<br>
			Gretzz:<br><marquee>Friends Cyber Army - Sunda Cyber Army - All Indonesian Defacer