
<html>
<head>
<link rel="SHORTCUT ICON" href="http://dev-xmen.pantheonsite.io/wp-content/uploads/2017/08/2q3abk0.jpg" type="image/x-icon"/>
<meta content='Hacked By Parkerzanta' name='description'/>

<meta content='Hacked By Parkerzanta' name='keywords'/>

<meta content='Hacked By Parkerzanta' name='Abstract'/>

<meta name="title" content="Defaced by Parkerzanta">

<meta name="description" content="22XploiterCrew">

<meta name="keywords" content="Parkerzanta">

<meta name="googlebot" content="index,follow" />

<meta name="robots" content="all" />

<meta name="robots schedule" content="auto" />

<meta name="distribution" content="global" />

 <meta property="og:image" content="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSJ17yapGqo79czdxUmWbokgbW6Psu8dMx3WW4oTT0wPWcq_g7L" />

  <link href="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Anonymous_emblem.svg/1200px-Anonymous_emblem.svg.png" rel="shortcut icon" />

<div style="height: auto; min-height: 100%;">

<div style="text-align: center; width:800px; margin-left: -400px; position: absolute; top: 30%; left: 50%;">

<img src="https://i.ibb.co/GF6Nz4G/anime-sad-girl-broken-inside-design-by-popculturemerch-dd7l3j5-fullview.jpg">

<body bgcolor="black">
<meta name="Author" content="22XploiterCrew"/>
<title>Hacked By Parkerzanta</title>
<div align="center">
 <pre style="font: 40px/10px courier;"><b>
<font color="white"> Hacked By Parkerzanta </font> 
</pre>
<pre style="font: 35px/0px courier;"><b><font color="red">22</font><font color="white">Xploiter</font><font color="red">C</font><font color="white">rew</font>
</div>
<pre style="font: 25px/40px courier;"><b>
<div><i><font color="white">teach me how to forget without hating:")<i><div>
</pre>
</div>
<div align="center">
<pre>
<div style=?text-align:left;?><font color="lime">
</pre>
</div>
  <iframe width="0" height="0" src="http://m.22xploitercrew.com/kerz.mp3" frameborder="0" allowfullscreen>
</body>
</html>
