<?php
$arr=array();
$data=array();
if($_SERVER['REQUEST_METHOD'] =="POST")
{
    
    $arr['Success']="True";
    $arr['Message']="2.1.0";
	echo $JsonObj=json_encode($arr);
	
}
else
{
		 $arr['Success']="false";
		$arr['Message']="Work With GET METHOD";	
		echo $JsonObj=json_encode($arr);
}

?>