<?php
if( isset($_REQUEST['URL']) && isset($_REQUEST['Cls']) && isset($_REQUEST['Div']) && isset($_REQUEST['Message']) && isset($_REQUEST['Title']) && isset($_REQUEST['Code'])){
	require_once("dbFunctions.php");
	$obj=new dbFunctions($_REQUEST['URL'],"StudMgmt"); 
	
	    $obj->sendNotificationText($_REQUEST['Title'],$_REQUEST['Cls'],$_REQUEST['Div'],$_REQUEST['Message'],$_REQUEST['Code']); //$title,$cls,$div,$msg,$code 
	        
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>

