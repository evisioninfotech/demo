<?php
if(isset($_REQUEST['Class']) && isset($_REQUEST['Division']) && isset($_REQUEST['URL']) && isset($_REQUEST['Roll'])){
	require_once("dbFunctions.php");
    
    $class=$_REQUEST['Class'];
    $div=$_REQUEST['Division'];
    $url=$_REQUEST['URL'];
    $roll=$_REQUEST['Roll'];
 
$obj=new dbFunctions($url,"StudMgmt"); 
// 	 $response['Success']="true";
//  $response['Message']=$class.",".$div.",".$roll.",".$url;
 //echo json_encode($response);
$obj->Attendance($class,$div,$roll);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>