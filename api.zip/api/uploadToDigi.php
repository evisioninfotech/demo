<?php
if( isset($_POST['URL']) && isset($_POST['Dir']) && isset($_FILES['image']) && isset($_POST['Code'])){
	require_once("dbFunctions.php");
	$obj=new dbFunctions($_POST['URL'],"StudMgmt"); 

            $obj->uploadToDigiLibrary($_FILES['image'],$_POST['Dir'],$_POST['URL'],$_POST['Code']);
	        
	/*        $response['Success']="true";
            $response['Message']="Marks Updated Successfully";
            echo json_encode($response);*/
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>