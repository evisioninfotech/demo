<?php
if(isset($_REQUEST['Arr']) && isset($_REQUEST['URL']) && isset($_REQUEST['Field']) && isset($_REQUEST['Subject']) && isset($_REQUEST['Term'])){


        
	require_once("dbFunctions.php");
	 $obj=new dbFunctions($_REQUEST['URL'],"StudMgmt"); 
	$arra=json_decode($_REQUEST['Arr'],true);
	for($i=0;$i<sizeof($arra);$i++){
	        
            $obj->MarksEntry($arra[$i]['S_id'],$_REQUEST['Subject'],$_REQUEST['Field'],$_REQUEST['Term'],$arra[$i]['Marks']); //$sid,$subject,$field,$term,$marks
	    }
	        $response['Success']="true";
            $response['Message']="Marks Updated Successfully";
            echo json_encode($response);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>

