<?php
if(isset($_REQUEST['FeedbackList']) && isset($_REQUEST['Message'])
&&    isset($_REQUEST['Class']) && isset($_REQUEST['Div'])
  &&  isset($_REQUEST['StudName']) && isset($_REQUEST['Mobile'])
    &&    isset($_REQUEST['Sex']) && isset($_REQUEST['URL']) ){
	require_once("dbFunctions.php");
    
     
    $url=$_REQUEST['URL'];
// $obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new dbFunctions($url,"StudMgmt");  
$obj->FeedbackInsert($_REQUEST['FeedbackList'],$_REQUEST['Message'],$_REQUEST['Class'],$_REQUEST['Div'],$_REQUEST['StudName'],$_REQUEST['Mobile'],$_REQUEST['Sex']);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>