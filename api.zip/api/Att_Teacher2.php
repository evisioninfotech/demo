<?php
if(isset($_REQUEST['Arr']) && isset($_REQUEST['URL']) && isset($_REQUEST['SMS']) && isset($_REQUEST['Subject'])){
	require_once("dbFunctions.php");
	 $obj=new dbFunctions($_REQUEST['URL'],"StudMgmt"); 
	$arra=json_decode($_REQUEST['Arr'],true);
	
	$subject=$_REQUEST['Subject'];
	$today=date('Y-m-d');
	$date=date('d');
	$month=date('m');
	$year=date('Y');
	
	
	
	for($i=0;$i<sizeof($arra);$i++){
     if($arra[$i]['Status'] == 'P'){
	        $status="PRESENT";
	    }else if($arra[$i]['Status'] == 'A'){
	        $status="ABSENT";
	    }
	        $data= $obj->getStudent($arra[$i]['S_id']);
	        $obj->setAttendance($arra[$i]['S_id'],$data['Class'],$data['Division'],$subject,$data['Roll_number'],$data['Name'],$data['Sex'],$data['Communication_number'],
	                            $today,$status,$date,$month,$year,$data['Nature_Student']);
	    }
	        $response['Success']="true";
            $response['Message']="Attendance Taken Successfully";
            echo json_encode($response);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>

