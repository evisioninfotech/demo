<?php
if(isset($_REQUEST['Class']) && isset($_REQUEST['Division']) && isset($_REQUEST['URL'] ) && isset($_REQUEST['Roll'] ) && isset($_REQUEST['ExamName'] ) 
    && isset($_REQUEST['ExamType'] ) && isset($_REQUEST['Term'] ) && isset($_REQUEST['S_id'] )){
	require_once("dbFunctions.php");
    
    $class=$_REQUEST['Class'];
     $division=$_REQUEST['Division'];
    $url=$_REQUEST['URL'];
     $sid=$_REQUEST['S_id'];
    
     $ename=$_REQUEST['ExamName'];
     $etype=$_REQUEST['ExamType'];
     $term=$_REQUEST['Term'];
    
    $roll=$_REQUEST['Roll'];
// $obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new dbFunctions($url,"StudMgmt");  
$obj->ExamMarks($class,$division,$roll,$ename,$etype,$term,$sid);
}
else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>