<?php
if(isset($_REQUEST['Class']) && isset($_REQUEST['Division']) && isset($_REQUEST['URL']) ){
	require_once("dbFunctions.php");
    
    $class=$_REQUEST['Class'];
    $division=$_REQUEST['Division'];
    $url=$_REQUEST['URL'];
// $obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new dbFunctions($url,"StudMgmt");  
$obj->Notification($class,$division);
}
else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>