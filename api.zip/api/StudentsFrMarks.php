<?php
if(isset($_REQUEST['CLS']) && isset($_REQUEST['Div']) && isset($_REQUEST['Subject']) && isset($_REQUEST['Field']) && isset($_REQUEST['Term']) && isset($_REQUEST['URL'])){
	require_once("dbFunctions.php");
$obj=new dbFunctions($_REQUEST['URL'],"StudMgmt");
$obj->getStudentsForMarksEntry($_REQUEST['CLS'],$_REQUEST['Div'],$_REQUEST['Subject'],$_REQUEST['Field'],$_REQUEST['Term']);
}
else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}


?>