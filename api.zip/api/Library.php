<?php
if(isset($_REQUEST['Key']) && isset($_REQUEST['URL']) ){
	require_once("dbFunctions.php");
    
    $url=$_REQUEST['URL'];
// $obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new dbFunctions($url,"Library");
$obj->Library($_REQUEST['Key']);
}
else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>