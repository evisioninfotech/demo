<?php
if(isset($_REQUEST['SID']) && isset($_REQUEST['URL']) ){
require_once("dbFunctions.php");
$obj=new dbFunctions($_REQUEST['URL'],"StudMgmt");
$obj->getTeacherClassesAndSubjects($_REQUEST['SID']);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>