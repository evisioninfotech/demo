<?php
if(isset($_REQUEST['SID']) && isset($_REQUEST['Password']) && isset($_REQUEST['URL'])){
	require_once("dbFunctions.php");
    
    $sid=$_REQUEST['SID'];
    $password=$_REQUEST['Password'];
    $url=$_REQUEST['URL'];
     require_once("Connection.php");
    $obj1 = new DB_Connect();

// $obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new dbFunctions($url,"StudMgmt");  
$obj->changePassword($sid,$password,$url);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>