<?php
if($_REQUEST['type'] == "s"){
if(isset($_REQUEST['Class']) && isset($_REQUEST['Division']) && isset($_REQUEST['URL']) && isset($_REQUEST['Date'])){
	require_once("dbFunctions.php");
    
    $class=$_REQUEST['Class'];
    $div=$_REQUEST['Division'];
    $url=$_REQUEST['URL'];
    $date=$_REQUEST['Date'];
 
$obj=new dbFunctions($url,"StudMgmt"); 
// 	 $response['Success']="true";
//  $response['Message']=$class.",".$div.",".$roll.",".$url;
 //echo json_encode($response);
$obj->Timetable($class,$div,$date);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}    
}else{
   
    if(isset($_REQUEST['SID']) && isset($_REQUEST['URL']) && isset($_REQUEST['Date'])){
	require_once("dbFunctions.php");
    $sid=$_REQUEST['SID'];
    $url=$_REQUEST['URL'];
    $date=$_REQUEST['Date'];
 
$obj=new dbFunctions($url,"StudMgmt"); 
$obj->TeacherTimetable($sid,$date);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
}

?>