<?php
if( isset($_POST['URL']) && isset($_POST['Cls']) && isset($_POST['Div']) && isset($_POST['Message']) && isset($_POST['Code'])){
	require_once("dbFunctions.php");
	$obj=new dbFunctions($_POST['URL'],"StudMgmt"); 
	if(isset($_FILES['image'])){
	    $link=$_FILES['image'];   
	}
	else{
	    $link="Notification For Class-".$_POST['Cls']." And Division-".$_POST['Div'];
	}
            $obj->sendNotification($link,$_POST['Cls'],$_POST['Div'],$_POST['Message'],$_POST['URL'],$_POST['Code']); //$file,$cls,$div,$msg,$url
	        
	/*        $response['Success']="true";
            $response['Message']="Marks Updated Successfully";
            echo json_encode($response);*/
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>

