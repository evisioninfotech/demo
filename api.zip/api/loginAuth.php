<?php
if(isset($_REQUEST['Username']) && isset($_REQUEST['Password']) && isset($_REQUEST['URL']) && isset($_REQUEST['fcm'])){
	require_once("dbFunctions.php");
    
    $username=$_REQUEST['Username'];
    $password=$_REQUEST['Password'];
    $url=$_REQUEST['URL'];
    $fcm=$_REQUEST['fcm'];
      
      
    require_once("Connection.php");
    $obj1 = new DB_Connect();
    $code=$obj1->getSchoolCodeByURL($url);
    
 
// $obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new dbFunctions($url,"StudMgmt");  
$obj->loginAuth($username,$password,$url,$fcm,$code);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>