<?php
         header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json");
        
class DB_Connect {
    
    private $con;
    private $schoolCode;
    private $mainCon;
    private $response=array();
    // constructor
    function __construct() {
        
    }

    // destructor
    function __destruct() {
        // $this->close();
    }

    // Connecting to database
    public function connect($dbusername,$dbpassword,$db) {
        
        // connecting to mysql
         $this->con = mysqli_connect("localhost", $dbusername, $dbpassword, $db);
        return $this->con;
    }

    public function getConByURL($url,$type){
    $this->mainCon = mysqli_connect("localhost","raghu80504822" ,"5EqjoMZIm2*b" , "admin_onlinefees_all");
    $res=mysqli_query($this->mainCon,"SELECT * FROM `schools` WHERE `schooldomain`='$url'")or die(mysqli_error($mainCon));
    $result=mysqli_fetch_array($res);

            if($type=="FEES"){
                return $this->connect($result['dbUsername'],$result['dbPassword'],$result['dbFees']);    
            }elseif($type=="StudMgmt"){
                    return $this->connect($result['dbUsername'],$result['dbPassword'],$result['dbStudent']);
            }elseif($type=="Library"){
                    return $this->connect($result['dbUsername'],$result['dbPassword'],$result['dbLibrary']);
            }
        }
        
         public function getSchoolNameByURL($url){
    $this->mainCon = mysqli_connect("localhost","raghu80504822" ,"5EqjoMZIm2*b" , "admin_onlinefees_all");
    $res=mysqli_query($this->mainCon,"SELECT `schoolname` FROM `schools` WHERE `schooldomain`='$url'")or die(mysqli_error($mainCon));
    $result=mysqli_fetch_array($res);

            
                    return $result['schoolname'];
            
        }
        
         public function getSchoolCodeByURL($url){
    $this->mainCon = mysqli_connect("localhost","raghu80504822" ,"5EqjoMZIm2*b" , "admin_onlinefees_all");
    $res=mysqli_query($this->mainCon,"SELECT `schoolCode` FROM `schools` WHERE `schooldomain`='$url'")or die(mysqli_error($mainCon));
    $result=mysqli_fetch_array($res);
                    return $result['schoolCode'];
        }
        
        public function schoolList(){
            $resp=array();
            $row=array();
           // echo "SELECT `schoolname`,`schooldomain` FROM `schools`";
              $this->mainCon = mysqli_connect("localhost","raghu80504822" ,"5EqjoMZIm2*b" , "admin_onlinefees_all");
    $res=mysqli_query($this->mainCon,"SELECT * FROM `schools`")or die(mysqli_error($mainCon));
    $response['Success']="true";
    while($result=mysqli_fetch_assoc($res)){
      //  echo $result['schoolname'];
       $resp["SchoolCode"]=utf8_encode($result['schooldomain']);
       $resp["SchoolName"]=utf8_encode($result['schoolname']);
       array_push($row,$resp);
      }
       
     
        $response['Data']=$row;
       
    	echo json_encode($response);
    	
    	
    
        }
        
         public function AdvtList(){
            $resp=array();
            $row=array();
           // echo "SELECT `schoolname`,`schooldomain` FROM `schools`";
              $this->mainCon = mysqli_connect("localhost","raghu80504822" ,"5EqjoMZIm2*b" , "admin_onlinefees_all");
    $res=mysqli_query($this->mainCon,"SELECT * FROM `Advt`")or die(mysqli_error($mainCon));
   
    while($result=mysqli_fetch_assoc($res)){
      //  echo $result['schoolname'];
       $resp["Discription"]=utf8_encode($result['Discription']);
       $resp["AdvtURL"]=utf8_encode($result['AdvtURL']);
       array_push($row,$resp);
      }
       
        $response['Success']="true";
        $response['Data']=$row;
       
    	echo json_encode($response);
    	
    	
    
        }

    



    // Closing database connection
    public function close() {
            mysqli_close();
    }

}

?>