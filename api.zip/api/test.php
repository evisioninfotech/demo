<?php
/*if(isset($_POST)){

$username=$_POST['Username'];
$password=$_POST['Password'];

require_once("dbFunctions.php");


$obj=new dbFunctions("http://demo.smsoft.in","FEES");
$obj=new C;  
$obj->loginAuth($username,$password);
	
}*/
 //header("Access-Control-Allow-Origin: *");
        //header("Content-Type: application/json; charset=UTF-8");
// require_once("Connection.php");
	require_once("dbFunctions.php");
$url="http://demo.smsoft.in";
$obj=new dbFunctions($url,"StudMgmt");
$obj->getStudentsForMarksEntry($_REQUEST['Cls'],$_REQUEST['Div'],$_REQUEST['Subject'],$_REQUEST['Field'],$_REQUEST['Term']);



?>