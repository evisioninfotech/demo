<?php 
require_once("Connection.php");
$obj = new DB_Connect();
$obj->schoolList();
?>