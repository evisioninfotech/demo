<?php
if(isset($_REQUEST['URL'])){
	require_once("dbFunctions.php");
    
    
    $url=$_REQUEST['URL'];
    
 
$obj=new dbFunctions($url,"StudMgmt"); 
$obj->EventsDates();
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>