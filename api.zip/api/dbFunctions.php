<?php
    // date_default_timezone_set("Asia/Kolkata");

class dbFunctions {

    private $con;
    private $schoolname;
    private $db;
    private $response=array();
    // public $currentTime=date("h:i:sa");
    // public $currentDate=date('Y-m-d');
    
		  	
    // constructor
    function __construct($url,$type) {
    	require_once("Connection.php");
    	$db=new DB_Connect();
        $this->con=$db->getConByURL($url,$type);
        $this->schoolname=$db->getSchoolNameByURL($url);
    }

    
    /*public function getDate(){
        return $this->currentDate;
    }
    
    public function getTime(){
        return $this->currentTime;
    }*/
    

    // destructor
    function __destruct() {
        // $this->close();
    }
    
    public function getStudent($sid){
        $res=mysqli_query($this->con,"SELECT * FROM `student_registration` WHERE `S_id`='$sid'");
        $result=mysqli_fetch_assoc($res);
        return $result;
    }
    
    public function changePassword($sid,$password,$url){
      $res1=mysqli_query($this->con,"UPDATE `student_registration` SET `Password` = '$password' WHERE `student_registration`.`S_id` = '$sid'")or die(mysqli_error($this->con));
        if($res1){
            $response['Success']="true";
            $response['Message']="Updated Successfully";
        }else{
            $response['Success']="false";
            $response['Message']="Something went wrong";
        }
        echo json_encode($response);

    }

    public function loginAuth($username,$password,$url,$fcm,$code){
            if($username != "" && $password != ""){
                 
    	$ress=mysqli_query($this->con,"SELECT 
    	`S_id`,`Name`,
    	`Communication_number`,
        `Class`,
        `Division`,
        `Roll_number`,
        `Sex`,
        `Register_number`,
        `Date_of_birth`,
        `Caste`,
        `Category`,
        `Religion`,
        `Father_Name`,
        `Mother_Name`,
        `Username`, 
        `Password`
                FROM `student_registration` WHERE `Username` = '$username' and `Password` = '$password'")or die(mysqli_error($this->con));
    	$result=mysqli_fetch_assoc($ress);
    	
    	
    	
    	
    	$res=array();
    	/*    
    	$res['S_id'] =  $result['S_id'];
        $res['Name'] =  $result['Name'];
        $res['Communication_number'] =  $result['Communication_number'];
        $res['Class'] = $result['Class'];
        $res['Division'] =  $result['Division'];
        $res['Roll_number'] =  $result['Roll_number'];
        $res['Sex'] = $result['Sex'];
        $res['Date_of_birth'] =$result['Date_of_birth'];
    	*/
    	  
    	if(mysqli_num_rows($ress) == 1){
    		$response['Success']="true";
     		array_push($res,$result);
    		$response['Data']=$res;
    		$response['domain']=$url;
    		$response['schoolName']=$this->schoolname;
    		$response['schoolcode']=$code;
    		if(($result['Class'] == 'Teacher' || $result['Division'] == 'Teacher') || ($result['Class'] == 'teacher' || $result['Division'] == 'teacher') || ($result['Class'] == 'TEACHER' || $result['Division'] == 'TEACHER')){
    		    $response['user_type']="TEACHER";    
    		}else{
    		    $response['user_type']="STUDENT";
    		}
    		
    		mysqli_query($this->con,"UPDATE `student_registration` SET `Physical_challenge_percent` = '$fcm' WHERE `S_id` = '$result[S_id]'");
    		$response['Message']="Login Success";
    			echo json_encode($response);
    			exit();
    	}else{
    		$response['Success']="false";
    		//$response['Data']="[]";
    		$response['Message']="Invalid Username or Password";
    		echo json_encode($response);
    			exit();
    	}
    	//echo json_encode($response);
            }
            else{
                $response['Success']="false";
    	 
    		$response['Message']="Username / Password Cannot be blank";
    			 
    			echo json_encode($response);
    			exit();
            }
    }
    
    public function FeesDetails($reg_number){
        $ar1=array();
        $res1=mysqli_query($this->con,"SELECT `Stud_Id` FROM `stud_basic` WHERE `Reg_No` = '$reg_number'")or die(mysqli_error($this->con));
        $row1=mysqli_fetch_assoc($res1);
        $res2=mysqli_query($this->con,"SELECT DISTINCT(`Head_Id`) FROM `stud_basic2` WHERE `Stud_Id`  = '$row1[Stud_Id]'")or die(mysqli_error($this->con));
        while($row2=mysqli_fetch_assoc($res2))
        {
            $code="";
            $amount="";
             $res3=mysqli_query($this->con,"SELECT SUM(`Total_Amount`) as a,SUM(`Paid`) as b,SUM(`Balance`) as c,(SELECT `Name` FROM `head` WHERE `Head_Id`='$row2[Head_Id]') as d FROM 
                                        `stud_basic2` WHERE `Head_Id` = $row2[Head_Id] and `Stud_Id` = '$row1[Stud_Id]'")or die(mysqli_error($this->con));
             $row3=mysqli_fetch_assoc($res3);
             
              /*$res4=mysqli_query($this->con,"SELECT `Recipt_No`as a, `Paid_date` as b, `Grand_Total` as c FROM `paid_fees` WHERE `Stud_Id` = '$row1[Stud_Id]' AND 
                                            `Head_Id` ='$row2[Head_Id]'")or die(mysqli_error($this->con));
                while($row4=mysqli_fetch_assoc($res4))
                {
                    if($code == ""){
                          $code=$row4['a']."/".$row4['b'];
                        $amount=$row4['c'];
                    }else{
                        $code=$code."*".$row4['a']."/".$row4['b'];
                        $amount=$amount."/".$row4['c'];  
                    }
                  
                }*/
             
             $ar2=array("HeadId"=>$row2['Head_Id'],"HeadName" => $row3['d'],"TotalAmount" => $row3['a'],"PaidAmount" => $row3['b'],"BalanceAmount" => $row3['c'],"RecDate" => $code,"AmountPaid" =>$amount);
             array_push($ar1,$ar2);
            // print_r($row3);
             
        }
        $response['Success']="true";
        $response['Data']=$ar1;
        echo json_encode($response);
    }
    
    public function FeesRecipts($reg_number,$headId){
         $res1=mysqli_query($this->con,"SELECT `Stud_Id` FROM `stud_basic` WHERE `Reg_No` = '$reg_number'")or die(mysqli_error($this->con));
        $row1=mysqli_fetch_assoc($res1);
                $ar1=array();
                
                // Replace This {Recipt_No} with {Recp_Book_No} 
                $res4=mysqli_query($this->con,"SELECT `Recipt_No`as a, `Paid_date` as b, `Grand_Total` as c FROM `paid_fees` WHERE `Stud_Id` = '$row1[Stud_Id]' AND 
                                            `Head_Id` ='$headId'")or die(mysqli_error($this->con));
                while($row4=mysqli_fetch_assoc($res4))
                {
                $ar2=array("ReciptName"=>$row4['a'],"Date" => $row4['b'],"Amount" => $row4['c']);
                array_push($ar1,$ar2);
                }
        $response['Success']="true";
        $response['Data']=$ar1;
        echo json_encode($response);
    }
    
    public function Attendance($class,$division,$roll){
        $ar1=array();
        $month=array("June"=>"06","July"=>"07","August"=>"08","September"=>"09","Octomber"=>"10","November"=>"11","December"=>"12","January"=>"01","February"=>"02","March"=>"03","April"=>"04","May"=>"05");
        foreach($month as $k=>$v){
        $res1=mysqli_query($this->con,"SELECT COUNT(S_id) as present,
        (SELECT COUNT(S_id) as a FROM `attendence` WHERE `Class` = '$class' and `Division` = '$division' and `Roll_number` = '$roll' and `MM` = '$v' and `Status` = 'ABSENT') as absent,
        (SELECT COUNT(S_id) as a FROM `attendence` WHERE `Class` = '$class' and `Division` = '$division' and `Roll_number` = '$roll' and `MM` = '$v' and `Status` = 'HO') as holiday 
        FROM `attendence` WHERE `Class` = '$class' and `Division` = '$division' and `Roll_number` = '$roll' and `MM` = '$v' and `Status` = 'PRESENT'")or die(mysqli_error($this->con));
        $row1=mysqli_fetch_assoc($res1);
        
        
        $ar2=array("present"=>$row1['present'],"absent"=>$row1['absent'],"holiday"=>$row1['holiday'],"month"=>$k,"monthNumber"=>$v);
        array_push($ar1,$ar2);
        
        }
    
        $response['Success']="true";
        $response['Data']=$ar1;
        echo json_encode($response);
    }
    
    public function AttendanceDayWise($class,$div,$month,$roll){
        $ar1=array();
        
        $res1=mysqli_query($this->con," SELECT `Subject` as s, DAY(`date`) as day,`IN_TIME` as inn,`OUT_TIME` as outt,`Status` as status FROM `attendence` 
        WHERE `Class` = '$class' and `Division` = '$div' and `Roll_number` = '$roll' and `MM` = '$month' ORDER BY `day` ASC")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1)){
              
        $ar2=array("Day"=>$row1['day'],"Subject"=>$row1['s'],"Status"=>$row1['status'],"In"=>$row1['inn'],"Out"=>$row1['outt']);
        array_push($ar1,$ar2);
        
        }
        $response['Success']="true";
        $response['Data']=$ar1;
        echo json_encode($response);
    }
    
    public function Notification($class,$division){
        $ar1=array();
     
        $res1=mysqli_query($this->con,"SELECT `link`,`Class`,`Division`,`note`,`date_time`,`extensions` FROM `notification` WHERE (`Class` = '$class' OR `Class` = 'All') 
                                        And (`Division` = '$division' OR `Division` = 'All') 
                                                ORDER BY `notification`.`id` DESC")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1))
        {
            
            if($row1['extensions'] =="JPEG" || $row1['extensions'] == "JPG" || $row1['extensions'] == "PNG" || $row1['extensions'] == "png" || $row1['extensions'] == "jpeg" || $row1['extensions'] == "jpg"){
                $ar2=array("Date"=>$row1['date_time'],"Title"=>$row1['note'],"Discription"=>$row1['link'],"Status"=>"2");
                array_push($ar1,$ar2);        
            }elseif($row1['extensions'] =="Text"){
                $ar2=array("Date"=>$row1['date_time'],"Title"=>$row1['note'],"Discription"=>$row1['link'],"Status"=>"1");
                array_push($ar1,$ar2);    
            }else{
                $ar2=array("Date"=>$row1['date_time'],"Title"=>$row1['note'],"Discription"=>$row1['link'],"Status"=>"0");
                array_push($ar1,$ar2);
            }
            
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function Events($date){
        $ar1=array();
     
        $res1=mysqli_query($this->con,"SELECT `Event` FROM `Events` WHERE `Date` = '$date'")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1))
        {
            $ar2=array("Message"=>$row1['Event']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function EventsDates(){
        $ar1=array();
     
        $res1=mysqli_query($this->con,"SELECT `Date` as d FROM `Events`")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1))
        {
            $ar2=array("Date"=>$row1['d']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function FeedbackList(){
        $ar1=array();
     
        $res1=mysqli_query($this->con,"SELECT `S_id` as id, `Suggestion` as text FROM `Suggestion_List`")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1))
        {
            
            $ar2=array("Id"=>$row1['id'],"Text"=>$row1['text']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function FeedbackInsert($FeedbackList, $Message, $class, $div, $StudName, $Mobile, $Sex){
        date_default_timezone_set("Asia/Kolkata");
         $timeAndDate=date("Y-m-d h:i:sa");
         
    $res1=mysqli_query($this->con,"INSERT INTO `Feed_Back` (`Type`, `Suggestion`, `Class`, `Division`, `Name`, `Communication`, `Sex`, `Date`, `Status`) VALUES
    ('$FeedbackList', '$Message', '$class', '$div', '$StudName', '$Mobile', '$Sex', '$timeAndDate', 'Pending')")or die(mysqli_error($this->con));
        if($res1){
            $response['Success']="true";
            $response['Message']="Updated Successfully";
        }else{
            $response['Success']="false";
            $response['Message']="Something went wrong";
        }
        // $response['Message']=$class."/".$division;
        echo json_encode($response);

    }
    
    public function Timetable($class,$div,$date){
        $ar1=array();
        $timestamp = strtotime($date);
        $day = date('l', $timestamp);
        $res1=mysqli_query($this->con,"SELECT `Time` as time, `Subject` as subject, `Teacher` as teacher, `ifChange` as status, `SubjectNew` as subnew, `TeacherNew` as newteacher FROM `timetable1` 
        WHERE `Class`= '$class' and `Division` = '$div' and `Day` = '$day' ")or die(mysqli_error($this->con));
        
        while($row1=mysqli_fetch_assoc($res1))
        {
            
            $ar2=array("Time"=>$row1['time'],"Subject"=>$row1['subject'],"Teacher"=>$row1['teacher'],"Alter"=>$row1['status'],"NewTeacher"=>$row1['newteacher'],"NewSubject"=>$row1['subnew']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    } 
    
    public function TeacherTimetable($sid,$date){
        $ar1=array();
        $timestamp = strtotime($date);
        $day = date('l', $timestamp);
        
 
        $res1=mysqli_query($this->con,"SELECT `Time` as time, `Subject` as subject, `Class` as cls , `Division` as divv , `ifChange` as statuss , `SubjectNew` as subnew, `TeacherNew` as newteacher FROM `timetable1` 
        WHERE `TS_id` = '$sid' and `Day` = '$day' ")or die(mysqli_error($this->con));
        
        while($row1=mysqli_fetch_assoc($res1))
        {
            $ar2=array("Time"=>$row1['time'],"Subject"=>$row1['subject'],"Teacher"=>$row1['cls']."/".$row1['divv'],"Alter"=>$row1['statuss'],"NewTeacher"=>$row1['newteacher'],"NewSubject"=>$row1['subnew']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function ExamsList($class,$div,$roll){
        $ar1=array();
        $res1=mysqli_query($this->con,"SELECT DISTINCT(`Exam_Name`) as exam FROM `exam` WHERE `Class` = '$class' and `Division`= '$div' and `Roll_number` = '$roll' ORDER BY `exam`.`Exam_Name` DESC");
        while($row1=mysqli_fetch_assoc($res1))
        {
            $ar2=array("Exam"=>$row1['exam'],"Type"=>"Normal");
            array_push($ar1,$ar2);
        }
        
        $res1=mysqli_query($this->con,"SELECT DISTINCT(`Discription`) as exam FROM `ccesubcatmaster`");
        while($row1=mysqli_fetch_assoc($res1))
        {
            $ar2=array("Exam"=>$row1['exam'],"Type"=>"CCE");
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function ExamMarks($class,$div,$roll,$ename,$etype,$term,$sid){
        $ar1=array();
        //NORMAL
        if($term == ""){
            $res1=mysqli_query($this->con,"SELECT DISTINCT(`subjects`) as subject FROM `master`");
        while($row1=mysqli_fetch_assoc($res1))
        {
             $res2=mysqli_query($this->con,"SELECT `$row1[subject]` as marks FROM `exam` WHERE `Class` = '$class' and `Division` = '$div' and `Roll_number` ='$roll' and `Exam_Name` = '$ename'");
                $row2=mysqli_fetch_assoc($res2);
                if($row2['marks'] != "" && $row2['marks'] != null){
                    $ar2=array("Subject"=>$row1['subject'],"Marks"=>$row2['marks']);
                    array_push($ar1,$ar2);  
                }   
                 
                
        }  
         $response['Success']="true";
         
        
        $response['Data']=$ar1;
        echo json_encode($response);
        }else{
            
                $res1=mysqli_query($this->con,"SELECT `Subjects` as subId FROM `student_exampanel` WHERE S_id = '$sid'");
                $row1=mysqli_fetch_assoc($res1);
                
                $subids_array=array_filter(explode("/",$row1['subId']));
                foreach($subids_array as $subids){
                    $res2=mysqli_query($this->con,"SELECT `Code` as code FROM `ccesubcatmaster` WHERE `Discription` = '$ename'");
                    $row2=mysqli_fetch_assoc($res2);
                    
                    $res3=mysqli_query($this->con,"SELECT `SubjectName` as tname FROM `ccesubjectmaster` WHERE `Id` = '$subids'");
                    $row3=mysqli_fetch_assoc($res3);
                  $field=$row2['code'];
                  $table=$row3['tname'];
                    
                     $res4=mysqli_query($this->con,"SELECT $field as marks FROM $table where `S_id` = '$sid' and `Term` = '$term'");
                      $row4=mysqli_fetch_assoc($res4);
                    $ar2=array("Subject"=>$table,"Marks"=>$row4['marks']);
                    array_push($ar1,$ar2);
                    
                }
                $response['Success']="true";
         
        
        $response['Data']=$ar1;
        echo json_encode($response);
                
        }
      }
      
    public function Library($key){
        $ar1=array();
        $key='%'.$key.'%';
        
        $res1=mysqli_query($this->con,"SELECT `id` as id, `TITLE` as title, `Barrowed` as status FROM `book_table` WHERE `TITLE` LIKE '$key' ")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1))
        {
            
            $ar2=array("Id"=>$row1['id'],"Name"=>$row1['title'],"Status"=>$row1['status']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    public function LibraryBook($key){
        $ar1=array();
        $res1=mysqli_query($this->con,"SELECT `TITLE` as Title, `Author_Name` as Author, `Accession_Num` as AccessNumber, `Section` as Section, 
        `Publisher` as Publisher,`Type` as Type,`Deprtment` as Department FROM `book_table` WHERE `id` = '$key'")or die(mysqli_error($this->con));
        while($row1=mysqli_fetch_assoc($res1))
        {
            
            $ar2=array("Title"=>$row1['Title'],"Author"=>$row1['Author'],"AccessNumber"=>$row1['AccessNumber'],"Section"=>$row1['Section'],
            "Publisher"=>$row1['Publisher'],"Type"=>$row1['Type'],"Department"=>$row1['Department']);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
        // $response['Message']=$class."/".$division;
        
        $response['Data']=$ar1;
        echo json_encode($response);

    }
    
    
    public function getTeacherClasses($sid){
        $ar1=array();
        $res=mysqli_query($this->con,"SELECT `Att-Type`,`Subject`, `AT_Class`, `AT_Division` FROM `Teacher_Sub_Class` WHERE `S_id`='$sid' and `AT_Class` != '' and  `AT_Division` != ''");
        while($row1=mysqli_fetch_assoc($res)){
            $ar2=array("Class"=>$row1['AT_Class'],"Division"=>$row1['AT_Division'],"Subject"=>$row1['Subject'],"Type"=>$row1['Att-Type']);
            array_push($ar1,$ar2);
        }
        $response['Success']="true";
        $response['Data']=$ar1;
        echo json_encode($response);
    }
    
     public function getDir(){
        $ar1=array();
        $res=mysqli_query($this->con,"SELECT `name` as n FROM `folders`");
        while($row1=mysqli_fetch_assoc($res)){
            $ar2=array("Class"=>$row1['n']);
            array_push($ar1,$ar2);
        }
        $response['Success']="true";
        $response['Data']=$ar1;
        echo json_encode($response);
    }
    
     public function getStudentsForAtt($cls,$div){
          $ar1=array();
          date_default_timezone_set('Asia/Kolkata');
          $today=date('Y-m-d');
          
        $res=mysqli_query($this->con,"SELECT `S_id`, `Name`, `Roll_number` FROM `student_registration` WHERE `Class` = '$cls' && `Division` = '$div' ORDER BY `student_registration`.`Name` ASC");
        while($row1=mysqli_fetch_assoc($res))
        {
             $r=mysqli_query($this->con,"SELECT * FROM `attendence` WHERE `S_id`='$row1[S_id]' and `date`='$today'");
            $rr=mysqli_fetch_assoc($r);
            if(mysqli_num_rows($r) > 0){
                if($rr['Status'] == "PRESENT"){
                    $status="P";
                }else if($rr['Status'] == "ABSENT"){
                    $status="A";
                }
            }else{
                $status="P";
            }
            $ar2=array("S_id"=>$row1['S_id'],"Name"=>$row1['Name'],"Roll"=>$row1['Roll_number'],"Status"=>$status);
            array_push($ar1,$ar2);
        }
    
        $response['Success']="true";
         $response['Message']="Students are There";
        
        $response['Data']=$ar1;
        echo json_encode($response);
         
    }
    
    public function setAttendance($sid,$class,$div,$subject,$roll,$name,$gender,$mobile,$today,$status,$date,$month,$year,$nature){
        date_default_timezone_set('Asia/Kolkata');
        $time=date("h:i:sa");
        $data=$this->attTakenOrNot($sid,$today,$status);
        if($data['status'] == 'U'){
            $sql="UPDATE `attendence` SET `Status` = '$status',`Att_Time`= '$time' WHERE `S_id` = '$sid' and `date` = '$today' ";
        }else if($data['status'] == 'I'){
            $sql= "INSERT INTO `attendence` 
                                (`id`,`S_id`, `Class`, `Division`, `Subject`, `Roll_number`, `Name`, `Sex`, `Mobile`, `date`, `Status`, `DD`, `MM`, `YYYY`, `Nature_Student`, `IN_TIME`, `OUT_TIME`,`Att_Time`) 
                                VALUES 
                                (NULL,'$sid', '$class', '$div', '$subject', '$roll', '$name', '$gender', '$mobile', '$today', '$status', '$date', '$month', '$year', 
                                '$nature', '00:00:00', '00:00:00','$time')";
        }
            $res=mysqli_query($this->con,$sql);
            return $res;
    }
    
    public function attTakenOrNot($sid,$date,$status){
        $res=mysqli_query($this->con,"SELECT * FROM `attendence` WHERE `S_id` = '$sid' and  `date` = '$date'");
        if($results=mysqli_num_rows($res) > 0){
            $result=mysqli_fetch_assoc($res);
        if($result['Status'] == $status){
               $response['status']='L';
        }else{
            $response['status']='U';
        }
        }else{
            $response['status']='I';
        }
        return $response;
    }
    
    public function getTeacherClassesAndSubjects($sid){
        $ar1=array();
 
        $res=mysqli_query($this->con,"SELECT `Subject`, `Class`, `Division` FROM `Teacher_Sub_Class` WHERE `S_id` = '$sid' ");
       
        while($row1=mysqli_fetch_assoc($res)){
            $ar2=array("Class"=>$row1['Class']."-".$row1['Division']."-".$row1['Subject']);
            array_push($ar1,$ar2);
        }
        $res1=mysqli_query($this->con,"SELECT `AT_Class`, `AT_Division` FROM `Teacher_Sub_Class` WHERE `S_id` = '$sid' ");
        while($row2=mysqli_fetch_assoc($res1)){
            $ar2=array("Class"=>$row2['AT_Class']."-".$row2['AT_Division']."-"."Section II");
            array_push($ar1,$ar2);
        }
        
        $response['Success']="true";
        $response['Subjects']=$ar1;
        $response['Section1']=$this->getSubCat();
        $response['Section2']=$this->getSectionIICat();
        echo json_encode($response);
    }
    
    public function getSubCat(){
        $ar1=array();
        $res=mysqli_query($this->con,"SELECT * FROM `ccesubcatmaster`");
        while($row1=mysqli_fetch_assoc($res)){
            $ar2=array("Field"=>$row1['Code']);
            array_push($ar1,$ar2);
        }
        return $ar1;
    }
    
    public function getSectionIICat(){
        $ar1=array();
        $res=mysqli_query($this->con,"SELECT * FROM `ccesection2master`");
        while($row1=mysqli_fetch_assoc($res)){
            $ar2=array("Field"=>$row1['Code']);
            array_push($ar1,$ar2);
        }
        return $ar1;
    }
    
    public function getStudentsForMarksEntry($cls,$div,$subject,$field,$term){
 
            if($subject == "Section II"){
                $subject= "ccesection2data";
            }  
                $subject=strtolower($subject);
              $ar1=array();
              $sql="SELECT  main.Roll_number as roll,
                            sub.$field as marks,
                            main.S_id as sid,
                            main.Name as name 
                                            FROM 
                                               $subject as sub JOIN student_registration as main 
                                                                ON 
                                                                    sub.S_id=main.S_id 
                                                                                        WHERE main.Class="."'$cls'"."
                                                                                        and 
                                                                                        main.Division="."'$div'"."
                                                                                        and 
                                                                                        sub.TERM="."'$term'"."
                                                                                     ORDER BY main.Name ASC";
            // echo $sql; 
            $res=mysqli_query($this->con,$sql);
            if($res){
                    while($row1=mysqli_fetch_assoc($res))
            {
                $ar2=array("S_id"=>$row1['sid'],"Name"=>$row1['name'],"Roll"=>$row1['roll'],"Marks"=>$row1['marks']);
                array_push($ar1,$ar2);
            }
            $response['Success']="true";
             $response['Message']="Students are There";
            $response['Data']=$ar1;
            }else{
                $response['Success']="false";
                $response['Message']="There is no Students";
        
            }
            echo json_encode($response);
             
        }
    
    public function MarksEntry($sid,$subject,$field,$term,$marks){
            if($subject == "Section II"){
                $subject= "ccesection2data";
            }  
            $subject=strtolower($subject);
            $ar1=array();
            $sql="UPDATE $subject SET $field  = $marks WHERE `S_id` = $sid and `Term` = $term";
            
            $res=mysqli_query($this->con,$sql);
            if($res){
                       
            }else{
                
            }
            //echo json_encode($response);
             
        }
        
    public function sendNotification($file,$cls,$div,$msg,$url,$code){
    date_default_timezone_set('Asia/Kolkata');
    $timestamp = time();
    $date_time = date("d-m-Y h:i a", $timestamp);
    if(isset($file["name"])){
        $fileinfo=PATHINFO($file["name"]);
    	$newFilename=rand(1,999) . rand(1001,9999). "." . $fileinfo['extension'];
    	move_uploaded_file($file["tmp_name"],"/home/ek439kzey1c5/public_html/".$code."/student_management_system/pages/upload/" . $newFilename);
    	$location=$url."/student_management_system/pages/upload/".$newFilename;
    	$ext=$fileinfo['extension'];    
    }

	
	
	$sql="INSERT INTO `notification` (`Class`,`Division`,`date_time`,`link`,`note`,`extensions`)  values ('$cls','$div','$date_time','$location','$msg','$ext')";
	$res=mysqli_query($this->con,$sql)or die(mysqli_error($this->con));
	 if($res){
	     $this->CloudMessage($code."-".trim($cls)."-".trim($div),"Notification for ".$cls." (C) -".$div."(D)",$msg);
	    $response['Success']="true";
        $response['Message']="Notificaion sent successfully.."; 
	 }else{
	    $response['Success']="false";
        $response['Message']="Somthing went wrong.";
	 }
        echo json_encode($response);
    }
    
    public function sendNotificationText($title,$cls,$div,$msg,$code){
    date_default_timezone_set('Asia/Kolkata');
    $timestamp = time();
    $date_time = date("d-m-Y h:i a", $timestamp);
    $sql="INSERT INTO `notification` (`Class`,`Division`,`date_time`,`link`,`note`,`extensions`)  values ('$cls','$div','$date_time','$title','$msg','')";
	$res=mysqli_query($this->con,$sql)or die(mysqli_error($this->con));
	 if($res){
	     $this->CloudMessage($code."-".trim($cls)."-".trim($div),"Notification for ".$cls." (C) -".$div."(D)",$msg);
	    $response['Success']="true";
        $response['Message']="Notificaion sent successfully.."; 
	 }else{
	    $response['Success']="false";
        $response['Message']="Somthing went wrong.";
	 }
        echo json_encode($response);
    }
    
    function CloudMessage($code,$title,$message)
        {
        // API access key from Google API's Console
        define( 'API_ACCESS_KEY', "AIzaSyC8GlmVD1P-_e9GrqfpM16GpODNUtIin_U");
        
        
        $topic="/topics/".$code;
        //echo $topic;
        // prep the bundle
        
        $msg = array
        (
            'body'  => $message,
            'title'     => $title,
            'vibrate'   => 1,
            'sound'     => 1,
        );
        
        $fields = array
        (
            'to'  => $topic,
            'notification'=> $msg,
            
        );
        
        $headers = array
        (
            'Authorization: key=' . API_ACCESS_KEY,
            'Content-Type: application/json'
        );
        
        $ch = curl_init();
        curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
        $result = curl_exec($ch );
        curl_close( $ch );
       // echo $result;
        
        }
   
   
   public function uploadToDigiLibrary($file,$dir,$url,$code){
    $path="/home/ek439kzey1c5/public_html/".$code."/student_management_system/student/".$this->getPath($dir);
    date_default_timezone_set('Asia/Kolkata');

    $timestamp = time();
    $date_time = date("d-m-Y", $timestamp);
    $date_time1 = date("d-m-Y", $timestamp);
 
 
 if(isset($file["name"])!="")
 {
     $fileinfo=PATHINFO($file["name"]);
    // print_r($fileinfo);
	 $newFilename=$fileinfo['filename'] ."_". "$date_time1" . "." . $fileinfo['extension'];
	
	
	try {
    //throw exception if can't move the file
    if (!$move=move_uploaded_file($file["tmp_name"],$path ."/". $newFilename)) {
        throw new Exception('Could not move file');
    }
    //echo "Upload Complete!";
} catch (Exception $e) {
   // die ('File did not upload: ' . $e->getMessage());
}
	//$move=move_uploaded_file($file["tmp_name"],$path ."/". $newFilename);
 }
 if($move){
	    // $this->CloudMessage($code."-".trim($cls)."-".trim($div),"Notification for ".$cls." (C) -".$div."(D)",$msg);
	    $response['Success']="true";
        $response['Message']="File Uploaded to Library"; 
}else{
	    $response['Success']="false";
        $response['Message']="Somthing went wrong.";
	 }
        echo json_encode($response);
    }
    
    public function getPath($name){
        $res=mysqli_query($this->con,"SELECT `path` as n FROM `folders` WHERE `name` = '$name'");
        $row1=mysqli_fetch_assoc($res);
        return $row1['n'];
        
    }
    
    

}
?>