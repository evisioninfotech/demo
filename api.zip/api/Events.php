<?php
if(isset($_REQUEST['Date']) && isset($_REQUEST['URL'])){
	require_once("dbFunctions.php");
    
    $date=$_REQUEST['Date'];
    $url=$_REQUEST['URL'];
    
 
$obj=new dbFunctions($url,"StudMgmt"); 
$obj->Events($date);
}else
{
	 $response['Success']="false";
	//$response['Data']="";
	$response['Message']="Fields Cannot be Blank";
	echo json_encode($response);
}
?>